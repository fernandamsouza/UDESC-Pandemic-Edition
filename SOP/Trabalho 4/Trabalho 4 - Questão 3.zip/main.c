// gcc main.c -o ./req-disco 
// Infelizmente não consegui terminar de implementar :/
// Em algum ponto ocorreu um segmentation fault que não consegui resolver pois não daria tempo, então escrevi o restante do código com a lógica da questão.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct elemento{
    void *campos;
    struct elemento *next;
    struct elemento *prev;
} Elemento;

typedef struct {
    int tamanhoCampos;
    Elemento *head;
} Lista;


struct campos {
    int blocoInicial, numeroBlocos;
    char operacao[2];
};

Elemento* inserirEmOrdem(Lista *l, void *campos);
void inicializarLista(Lista *l, int t);
Elemento* fundir (Lista *l, Elemento *atual);
void exibirLista(Lista l);

int main(int argc, char const *argv[]){

  FILE *f;
  int inicio, numero;
  char operacao[2];
  // R6 - Não há limite predefinido para o tamanho da lista de requisições.
  Lista requisicoes;
  inicializarLista (&requisicoes, sizeof(struct campos));
  f = fopen("a.txt", "r");
  // R1 - O programa deve ler requisições de disco da entrada padrão (uma requisição por linha).
  // R2 - A leitura encerra quando o bloco inicial for −1. Essa requisição deve ser ignorada.
  while (fscanf(f, "%u %u %s", &inicio, &numero, operacao) != -1) {
        struct campos entrada;
        entrada.blocoInicial = inicio;
        entrada.numeroBlocos = numero;
        strcpy(entrada.operacao, operacao);
        printf("%u %u %s\n", inicio, numero, operacao);
        // R3 - As requisições lidas devem ser inseridas em uma fila de despacho, que deve ser ordenada pelo número do bloco.
        Elemento *aux2 = inserirEmOrdem(&requisicoes, &entrada);
        while ((aux2 = fundir(&requisicoes, aux2))!= NULL);
  }
  // R7 - Quando a leitura for encerrada, o programa deve imprimir uma linha contendo “Fila:” e exibir o conteúdo da lista, uma requisição por linha, com campos separados por um espaço (veja o exemplo abaixo).
  printf("Fila:\n");
  exibirLista(requisicoes);
}

void exibirLista(Lista l) {
    Elemento *aux = l.head;
    if (aux == NULL)
        return;
    int cont = 0;
    while(aux != NULL) {
        struct campos *campo = l.head->campos;
        printf("%u %u %s\n", campo->blocoInicial, campo->numeroBlocos, campo->operacao);
        aux = aux->next;
    }
}

// Fundição de blocos
Elemento* fundir (Lista *l, Elemento *atual) {
    struct campos *requesicaoAnterior, *requesicaoAtual;
    int total = 0, numerodeBlocos = 0;
    Elemento *prev = atual->prev;
    Elemento *next = atual->next;
    requesicaoAtual = (struct campos*) atual->campos;
    requesicaoAnterior = (struct campos*) prev->campos;
        if (requesicaoAnterior->blocoInicial + requesicaoAnterior->numeroBlocos == requesicaoAtual ->blocoInicial) {
            // R4 - Também devem ser fundidas requisições de leitura onde haja sobreposição de blocos.
            if (requesicaoAnterior->blocoInicial + requesicaoAnterior->numeroBlocos >= requesicaoAtual->blocoInicial) {
                // R4 - Requisições com a mesma operação que sejam adjacentes devem ser fundidas em uma única requisição
                if (strcmp(requesicaoAnterior->operacao, requesicaoAtual->operacao) == 0) {
                    if (requesicaoAtual->blocoInicial + requesicaoAtual->numeroBlocos -1 > requesicaoAnterior->blocoInicial + requesicaoAnterior->numeroBlocos -1) {
                        total = requesicaoAtual->blocoInicial + requesicaoAtual->numeroBlocos -1;
                        numerodeBlocos = total - requesicaoAnterior->blocoInicial+1;
                    }
                    else {
                        total = requesicaoAnterior->blocoInicial + requesicaoAnterior->numeroBlocos -1;
                        numerodeBlocos = total - requesicaoAnterior->blocoInicial+1;
                    }
            }
        }
    }
    // R4 - Respeita-se o limite para o número de 64 blocos por requisição.
    if (numerodeBlocos <= 64) {
        requesicaoAnterior->numeroBlocos = numerodeBlocos;
        free(atual->campos);
        free(atual);
        return prev;
    }
    return NULL;
}

void inicializarLista(Lista *l, int t) {
    l->tamanhoCampos = t;
    l->head = NULL;
}

Elemento* inserirEmOrdem(Lista *l, void *campos) {
    int i = 0, contador = 0;
    Elemento *aux = l->head;
    while (contador < i-1 && aux->next != NULL) {
        aux = aux->next;
        contador++;
    }

    Elemento *aux2;
    aux2->campos = malloc(l->tamanhoCampos);
    memcpy(aux2->campos, campos, l->tamanhoCampos);
    aux2->prev = aux;
    aux2->next = aux->next;
    aux->next = aux2;
    if(aux2->next != NULL)
        aux2->next->prev = aux2;
    return aux2;
}
